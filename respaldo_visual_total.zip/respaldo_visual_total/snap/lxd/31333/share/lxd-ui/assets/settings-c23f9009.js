const e=r=>!!(r!=null&&r.config["network.ovn.northbound_connection"]),n=r=>{var o;return((o=r==null?void 0:r.environment)==null?void 0:o.server_clustered)??!1};export{n as i,e as s};
